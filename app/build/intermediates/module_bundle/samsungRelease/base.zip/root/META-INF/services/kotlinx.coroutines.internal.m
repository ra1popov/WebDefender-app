q8.a
